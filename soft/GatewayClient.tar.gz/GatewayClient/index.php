<?php
require_once 'Gateway.php';
use GatewayClient\Gateway;

/**
 *====这个步骤是必须的====
 *这里填写Register服务的ip和Register端口，注意端口不是gateway端口
 *ip不能是0.0.0.0，端口在start_register.php中可以找到
 *这里假设GatewayClient和Register服务都在一台服务器上，ip填写127.0.0.1。
 *如果不在一台服务器则填写真实的Register服务的内网ip(或者外网ip)
 **/
Gateway::$registerAddress = '127.0.0.1:1236';
$uid = "500019";
$username = "我不是你的小鹿";
$n = mt_rand(1,20);
$image  = "http://img.zb123.tech/avatar/B0{$n}.jpg";

$data = [
    'roomId' => '1000',
    'userId' => $uid,
    'type'   => '2002',
    'content' => [
    'room_id' => '1000',
    'amount'  => '42434.94',
    'mine'    => '8',
    'num'     => '7',
    'money'   => '11',
    'uid'     => $uid,
    'username' => $username,
    'image'    => $image,
    'hbao_id'  => '102851',
    'hbao_date' => "2020-12-21 13:49:29",
    'hbao_life_date' => '2020-12-21 13:54:29',
    ]
];
$message = json_encode($data,true);
Gateway::sendToAll($message);