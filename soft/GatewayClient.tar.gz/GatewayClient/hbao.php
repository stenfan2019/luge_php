<?php
require_once 'Gateway.php';
use GatewayClient\Gateway;

Gateway::$registerAddress = '127.0.0.1:1236';

$message = $_POST['message'];
if($message){
    $message = urldecode($message);
    $data = json_decode($message,true);
    $type    = $data['type'];
    if('2001' == $type){
        Gateway::sendToAll($message);
    }
    
    if('2002' == $type){
        Gateway::sendToAll($message);
    }
    
    if('2003' == $type){
       $filename =  './conf/redis.ini';
       $conf = parse_ini_file($filename,TRUE);
       ini_set('default_socket_timeout', -1); //redis不超时
       $redis = new \Redis();
       $redis->connect($conf['host'], $conf['port']);
       $redis->auth($conf['password']);
       $redis->select($conf['database']);
       
       //寻找client_id
       $uid = $data['content']['userid'];
       $key = "hbao:client_id:$uid";
       $send_clientId = $redis->get($key);
       Gateway::sendToClient($send_clientId, $message);
        //Gateway::sendToAll($message);
    }
    
    
}
