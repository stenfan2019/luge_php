<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 用于检测业务代码死循环或者长时间阻塞等问题
 * 如果发现业务卡死，可以将下面declare打开（去掉//注释），并执行php start.php reload
 * 然后观察一段时间workerman.log看是否有process_timeout异常
 */
//declare(ticks=1);

/**
 * 聊天主逻辑
 * 主要是处理 onMessage onClose 
 */
use \GatewayWorker\Lib\Gateway;

class Events
{
   public static function onWorkerStart()
   {
       echo "Gatewayworker Start\n";
       $filename = '/data/work/live_socket/conf/redis.ini';
       $conf = parse_ini_file($filename,TRUE);
       ini_set('default_socket_timeout', -1); //redis不超时
       global $redis;
       $redis = new \Redis();
       $redis->connect($conf['host'], $conf['port']);
       $redis->auth($conf['password']);
       $redis->select($conf['database']);
       
   }
   
   /**
    * 有消息时
    * @param int $client_id
    * @param mixed $message
    */
   public static function onMessage($client_id, $message)
   {
        global $redis;
        // debug
        echo "client:{$_SERVER['REMOTE_ADDR']}:{$_SERVER['REMOTE_PORT']} gateway:{$_SERVER['GATEWAY_ADDR']}:{$_SERVER['GATEWAY_PORT']}  client_id:$client_id "." onMessage:".$message."\n";
       
        $time = 86400;
        // 客户端传递的是json数据
        $message_data = json_decode($message, true);
        

        if(!$message_data)
        {
            return ;
        }

        
        $content  = $message_data['content'];
        $room_id  = $message_data['roomId'];
        $user_id  = $message_data['userId'];
        $type     = $message_data['type'];
        $type     = ($type == '1050') ? 1010 : $type;
        
        if('1010' == $type){
            $user_key = "live:user:$user_id";
            $redis->setex($user_key,$time,json_encode($content,true));
        }
        
       
        // 根据类型执行不同的业务
        switch($type)
        {
            // 客户端回应服务端的心跳
            case 'pong':
                return;
            // 客户端登录 message格式: {type:1010, content:xx, roomId:1} ，添加到客户端，广播给所有客户端xx进入聊天室
            case '1010':
                // 判断是否有房间号
                if(!isset($room_id))
                {
                    throw new \Exception("\$room_id not set. client_ip:{$_SERVER['REMOTE_ADDR']} \$message:$message");
                }
                
                //redis 将用户加入房间列表
                $live_room_user_key = 'live:room:'.$room_id.':user';
                $redis->sAdd($live_room_user_key,$user_id);
                $message = json_encode($message,true);
                //用户加入房间
                Gateway::joinGroup($client_id, $room_id);
                //通知房间的人，有新用户进入
                Gateway::sendToGroup($room_id, $message);
                
                // 获取房间内所有用户列表 
                $itmes = $redis->sMembers($live_room_user_key);
                $user_list = [];
                foreach ($itmes as $uid){
                    $key  = "live:user:$uid";
                    $user_list[] = json_decode($redis->get($key),true);
                }
                // 给当前用户发送用户列表 
                $new_message = array(
                    'type'   => $type,
                    'roomId' => $room_id,
                    'userId' => $user_id,
                    'content'=> $user_list
                );
                Gateway::sendToCurrentClient(json_encode($new_message,true));
                return;
                
            // 客户端发言 message: {type:say, to_client_id:xx, content:xx}
            case '1040':
                // 非法请求
                if(!isset($_SESSION['room_id']))
                {
                    throw new \Exception("\$_SESSION['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']}");
                }
                $room_id = $_SESSION['room_id'];
                $client_name = $_SESSION['client_name'];
                
                // 私聊
                if($message_data['to_client_id'] != 'all')
                {
                    $new_message = array(
                        'type'=>'say',
                        'from_client_id'=>$client_id, 
                        'from_client_name' =>$client_name,
                        'to_client_id'=>$message_data['to_client_id'],
                        'content'=>"<b>对你说: </b>".nl2br(htmlspecialchars($message_data['content'])),
                        'time'=>date('Y-m-d H:i:s'),
                    );
                    Gateway::sendToClient($message_data['to_client_id'], json_encode($new_message));
                    $new_message['content'] = "<b>你对".htmlspecialchars($message_data['to_client_name'])."说: </b>".nl2br(htmlspecialchars($message_data['content']));
                    return Gateway::sendToCurrentClient(json_encode($new_message));
                }
                
                $new_message = array(
                    'type'=>'say', 
                    'from_client_id'=>$client_id,
                    'from_client_name' =>$client_name,
                    'to_client_id'=>'all',
                    'content'=>nl2br(htmlspecialchars($message_data['content'])),
                    'time'=>date('Y-m-d H:i:s'),
                );
                return Gateway::sendToGroup($room_id ,json_encode($new_message));
        }
   }
   
   /**
    * 当客户端断开连接时
    * @param integer $client_id 客户端id
    */
   public static function onClose($client_id)
   {
       // debug
       echo "client:{$_SERVER['REMOTE_ADDR']}:{$_SERVER['REMOTE_PORT']} gateway:{$_SERVER['GATEWAY_ADDR']}:{$_SERVER['GATEWAY_PORT']}  client_id:$client_id onClose:''\n";
       
       // 从房间的客户端列表中删除
       if(isset($_SESSION['room_id']))
       {
           $room_id = $_SESSION['room_id'];
           $new_message = array('type'=>'logout', 'from_client_id'=>$client_id, 'from_client_name'=>$_SESSION['client_name'], 'time'=>date('Y-m-d H:i:s'));
           Gateway::sendToGroup($room_id, json_encode($new_message));
       }
   }
  
}
