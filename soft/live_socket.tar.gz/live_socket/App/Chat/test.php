<?php
$filename = '../../conf/redis.ini';
$data = parse_ini_file($filename,TRUE);
print_r($data);